/**
 * Main package for this application. All other packages will be sub packages of this package.
 * Contains the starting method for the method and any classes pertain to the overall application.
 *
 * @author John Mitchell (john@lambdaschool.com) with Lambda School unless otherwise noted.
 */
package com.lambdaschool.oktafoundation;