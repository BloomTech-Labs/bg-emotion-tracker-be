package com.lambdaschool.oktafoundation.views;


import com.lambdaschool.oktafoundation.models.Member;

import java.util.List;

public class MemberPositivity {
    private String memberid;
    private Double positivity;

    public String getMemberid() {
        return memberid;
    }

    public void setMemberid(String memberid) {
        this.memberid = memberid;
    }

    public Double getPositivity() {
        return positivity;
    }

    public void setPositivity(Double positivity) {
        this.positivity = positivity;
    }

    public MemberPositivity() {
    }


}


