/**
 * Contains the access points, end points, that can be used by clients.
 *
 * @author John Mitchell (john@lambdaschool.com) with Lambda School unless otherwise noted.
 */
package com.lambdaschool.oktafoundation.controllers;