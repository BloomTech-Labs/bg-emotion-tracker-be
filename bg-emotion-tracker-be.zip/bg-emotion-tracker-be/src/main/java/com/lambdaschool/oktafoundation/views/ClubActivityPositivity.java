package com.lambdaschool.oktafoundation.views;


public class ClubActivityPositivity {
    private String clubname;
    private String activityname;
    private Double positivity;

    public String getClubname() {
        return clubname;
    }

    public void setClubname(String clubname) {
        this.clubname = clubname;
    }

    public String getActivityname() {
        return activityname;
    }

    public void setActivityname(String activityname) {
        this.activityname = activityname;
    }

    public Double getPositivity() {
        return positivity;
    }

    public void setPositivity(Double positivity) {
        this.positivity = positivity;
    }

    public ClubActivityPositivity() {
    }


}


