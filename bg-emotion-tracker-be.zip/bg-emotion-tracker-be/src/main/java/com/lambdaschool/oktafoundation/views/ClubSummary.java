package com.lambdaschool.oktafoundation.views;

public interface ClubSummary {
   long getClubid();
   String getClubname();
}
