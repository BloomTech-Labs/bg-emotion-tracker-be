package com.lambdaschool.oktafoundation.views;

import java.util.Date;

public interface ClubsCheckInOutSummary {
    long getClubid();
    long getReactionid();
    long getActivityid();
    long getMember();
}
