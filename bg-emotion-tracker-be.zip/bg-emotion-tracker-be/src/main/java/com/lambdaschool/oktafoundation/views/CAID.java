package com.lambdaschool.oktafoundation.views;


import com.lambdaschool.oktafoundation.models.Member;

import java.util.List;

public class CAID {
   private long activityid;

   public long getActivityid() {
      return activityid;
   }

   public void setActivityid(long activityid) {
      this.activityid = activityid;
   }

   public long getClubid() {
      return clubid;
   }

   public void setClubid(long clubid) {
      this.clubid = clubid;
   }

   private long clubid;

   public CAID() {
   }


}


